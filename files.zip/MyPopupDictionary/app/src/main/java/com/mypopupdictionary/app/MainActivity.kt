package com.mypopupdictionary.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * This screen is only shown when the user taps the app icon directly.
 * It has no dictionary features itself - it just explains how to use the
 * popup, since the real feature (PopupActivity) is triggered from the
 * text-selection menu in OTHER apps, not from here.
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
