# My Popup Dictionary — Android source project

## What this app does

It uses Android's built-in **"Process Text"** mechanism. When you select
(long-press) any word in **any** app on your phone — browser, WhatsApp,
notes, PDF reader, anything — Android shows a small selection toolbar with
options like Copy/Share/Web search. This app adds **"My Popup Dictionary"**
to that toolbar automatically. Tap it, and a small floating card pops up
over whatever you were doing, showing:

- Meaning in **English**
- Meaning in **Hindi**
- Pronunciation (phonetic spelling + a speaker button that reads it aloud
  using the phone's built-in text-to-speech)
- Part of speech (noun, verb, etc.)
- Synonyms
- Antonyms

Tap anywhere outside the card and it closes instantly — no extra code
needed for that, it's handled by the popup's theme.

This approach was chosen deliberately over a "floating bubble that watches
your screen" approach (which needs the risky "draw over other apps" /
Accessibility Service permissions and is much more likely to get an app
rejected from the Play Store, or flagged as spyware-like by Android
itself). This version needs only internet access.

## ⚠️ Important — what I could and couldn't do for you

I can't compile or sign an installable `.apk` file myself — that requires
the Android SDK, Gradle, and a build machine, none of which are available
to me. What's in this project is the **complete, working source code** for
the app. You (or anyone) can turn it into an installable APK for free in
about 10 minutes using Android Studio. Steps below.

## How to turn this into an installable app (free, ~10 minutes)

1. Install **Android Studio** (free): https://developer.android.com/studio
2. Open Android Studio → **New Project** → **Empty Views Activity** →
   - Name: `My Popup Dictionary`
   - Package name: `com.mypopupdictionary.app`
   - Language: **Kotlin**
   - Minimum SDK: **API 24**
   - Click Finish and let it sync once (this generates the launcher icons
     and gradle wrapper this zip doesn't include).
3. Now copy these files from this zip **into** that new project, replacing
   the generated ones with the same name:
   - `app/src/main/AndroidManifest.xml`
   - `app/src/main/java/com/mypopupdictionary/app/MainActivity.kt`
   - `app/src/main/java/com/mypopupdictionary/app/PopupActivity.kt` (new file)
   - `app/src/main/res/layout/activity_main.xml`
   - `app/src/main/res/layout/activity_popup.xml` (new file)
   - `app/src/main/res/values/strings.xml`
   - `app/src/main/res/values/colors.xml`
   - `app/src/main/res/values/themes.xml` (or merge into existing themes.xml)
   - `app/build.gradle` — merge the `dependencies` block into the one
     Android Studio generated (just add the `cardview` line if it's missing)
4. Click the "Sync Now" banner that appears.
5. Plug in your phone (with USB debugging enabled) or use an emulator, and
   click the green **Run ▶** button. The app installs and launches.
6. To get a shareable APK file: **Build → Build Bundle(s)/APK(s) → Build
   APK(s)**. Android Studio will show a "locate" link to the generated
   `.apk`, which you can copy to your phone and install directly (you'll
   need to allow "install unknown apps" for whichever app you transfer it
   with).

## Notes on the dictionary sources

- English definitions: [dictionaryapi.dev](https://dictionaryapi.dev) —
  free, no signup needed.
- Hindi translation: [MyMemory Translation API](https://mymemory.translated.net)
  — free tier, no signup needed for light use. It's a translation engine
  rather than a curated Hindi dictionary, so translations are good for
  common words but occasionally rough for idioms or rare words. If you
  want higher-quality Hindi definitions later, you could swap this for a
  paid API (e.g. Google Cloud Translation) — the code to swap is isolated
  in the `lookupWord()` function in `PopupActivity.kt`.
- Both are free/best-effort APIs with no guaranteed uptime — fine for
  personal use, but if you ever plan to publish this on the Play Store
  for others to use, check their terms of service for commercial limits.

## Customizing

- App icon: Android Studio's New Project wizard already generated a
  default launcher icon for you — replace it via
  **File → New → Image Asset** if you want a custom one.
- Colors/branding: edit `res/values/colors.xml`.
- Card size/limit: `activity_popup.xml` caps the popup height at 480dp so
  long entries scroll instead of covering the whole screen — adjust
  `android:maxHeight` there if you want it bigger/smaller.
